CREATE VIEW dbo.Vw_receivables
AS
SELECT   a.ID, a.BillID, b.contract_i, a.ReceivablesID, a.no, a.commodity, a.ServiceID, a.customer, a.tank, a.OccurDate, a.Price, 
                a.Cent, a.TaxRate, a.Number, CAST(a.Number * a.Price AS numeric(15, 2)) AS total2, a.PailWeight, a.DeductMoney, 
                a.DeductReason, a.InvoiceNo, a.InvoiceDate, a.OperatorID, a.CreateDate, a.Type, a.State, a.Remarks, 
                dbo.Service.Name, dbo.Service.Unit, dbo.Service.ChargeType, d.c_name, a.amount
FROM      dbo.Receivables AS a INNER JOIN
                dbo.contract AS b ON a.BillID = b.id INNER JOIN
                dbo.Service ON a.ServiceID = dbo.Service.ServiceID INNER JOIN
                dbo.Vw_chargetype AS d ON dbo.Service.ChargeType = CAST(d.e_name AS int)
WHERE   (a.State = 0) AND (ISNULL(a.d, ' ') = ' ')
go

