



CREATE PROCEDURE [dbo].[readcrc]
(
@Time1 datetime,
@Time2 datetime
)
AS
 
   begin
	SELECT     c_customer, vessel,item_no, date2, commodity,tank,actual  	FROM crc WHERE (ISNULL(d, '') <> 'D') AND (date2 >= @time1) AND (date2 <= @time2) 
end



go

