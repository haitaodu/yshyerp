
CREATE PROCEDURE  [dbo].[w_no]
@t_field VARCHAR(20),
@t_no VARCHAR(6)='0',
@output VARCHAR(6) output
AS
DECLARE
 @l_sql nVARCHAR(800),
 @t_no1 VARCHAR(6),
 @t_no2 VARCHAR(6)
 set @l_sql=N'';

 
/*
處理update 的部分
*/
BEGIN TRANSACTION   
	if isnull(@t_field,'')='' and not @t_field in('cdc_no','crc_no','ttc_no','adc_no','dra_no','dfc_no','mix_no','qsa_no','eta_no','job_no','vessel_no','bulk_no','freetax_no','djob_no','sjob_no','ship_no','send_no','fee_no','plan_no','ReceivablesID','useno','amountno','w1','w2','c1','c2')
		return 0 
    else
		begin
			set @l_sql=N'select @a ='+@t_field+' from sysdata' 
			print @l_sql
			exec sp_executesql @l_sql ,N'@a varchar(6) out',@a=@t_no1 out
			print @t_no1
			if (isnull(@t_no,'')='' or isnull(@t_no,'')='0')
				begin
					set @t_no2=rtrim(ltrim(STR(cast(@t_no1 as int) + 1)))
					set @t_no2=REPLICATE('0',6-len(@t_no2))+@t_no2 
				end	 
			else
				begin
					set @t_no2=REPLICATE('0',6-len(@t_no))+@t_no
				end
			set @l_sql=N'update sysdata set '+@t_field+' ='''+ @t_no2+'''' 
			print @l_sql
			exec(@l_sql) 
		end
		--set @l_sql=N'select @output ='+@t_field+' from sysdata' 
		--exec sp_executesql @l_sql

if   @@error=0   
	COMMIT TRANSACTION
else   
	rollback  TRANSACTION
select @t_no2
RETURN @t_no2


go

