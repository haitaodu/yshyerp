CREATE PROCEDURE [dbo].[readweight]
  
AS
 
   begin
   DECLARE @count int
    DECLARE @strSta  VARCHAR(2)
    SET @count = 1
  CREATE TABLE #t(station char(2) ,tank char(7) default '',commodity char(15) default '',c_quan decimal(5,2) default 0,status char(2) default '',weight int default 0,level decimal(5,2) default 0,flow decimal(5,1) default 0)
   WHILE @count <=10
    BEGIN
 	SET @strSta =right(str(@count +100),2)
	exec('INSERT INTO #t  SELECT c_station,ttdctemp.tank,commodity,c_quan,status,(select [weight'+@strSta+'] from ttdcweight) as weight,tank_rd.level,tank_rd.flow FROM ttdctemp,tank_rd where d='''' and ''T-''+SUBSTRING(ttdctemp.tank,3,4)=tank_rd.tank and c_station='''+@strSta+'''') 
             SET @count = @count +1
     end 	
  select * from #t
  drop table #t
  end
go

