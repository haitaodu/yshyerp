CREATE VIEW dbo.View_contract
AS
SELECT     contract_i, customer, st_date, en_date, chk_date, con_long, tank, commodity, min_input
FROM         dbo.contract
WHERE     (ISNULL(d, ' ') = ' ')
go

