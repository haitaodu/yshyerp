CREATE VIEW dbo.View_tank
AS
SELECT     TOP (100) PERCENT tank, t_customer, commodity, date, safety_v, density, quantity, bs, temp1, temp2, tg, bw, allow_comm
FROM         dbo.tank
WHERE     (LEFT(tank, 1) = 'T')
ORDER BY tank
go

