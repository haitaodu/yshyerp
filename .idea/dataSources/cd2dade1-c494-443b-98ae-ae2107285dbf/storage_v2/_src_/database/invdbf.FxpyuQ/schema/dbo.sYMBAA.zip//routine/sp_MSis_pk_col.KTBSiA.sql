create proc sp_MSis_pk_col @source_table sysname, @colname sysname, @indid int
as
begin
    declare @indkey int
    select @indkey = 1
    while @indkey < 16 and index_col(@source_table, @indid, @indkey) is not null
    begin
        if index_col(@source_table, @indid, @indkey) = @colname
            return (1)
        select @indkey = @indkey + 1
    end
    return (0)
end
EXEC dbo.sp_MS_marksystemobject sp_MSis_pk_col
go

