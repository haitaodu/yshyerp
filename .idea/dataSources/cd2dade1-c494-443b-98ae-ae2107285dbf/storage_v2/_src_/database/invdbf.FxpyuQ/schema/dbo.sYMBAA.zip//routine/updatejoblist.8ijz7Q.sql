CREATE PROCEDURE  updatejoblist

@intID INT,

@strGH VARCHAR(3),

@strSTATUS VARCHAR(10)

AS

DECLARE

 @strUNIT_NAME VARCHAR(800)


 

SET @strUNIT_NAME=''


 

/*

處理update 的部分

*/

BEGIN TRANSACTION                                       

         IF @intID>0

        BEGIN

UPDATE job_list set scanstatus=@strSTATUS,scantime=getdate(),gh=@strGH
WHERE (SUBSTRING(job_no, 2, 6) IN
          (SELECT sjob_no
         FROM shipjob
         WHERE (item_no IN
                   (SELECT shipjob.item_no
                  FROM job_list INNER JOIN
                        shipjob ON SUBSTRING(job_list.job_no, 2, 6) 
                        = shipjob.sjob_no
                  WHERE (job_list.id = @intID))))) AND (d = '') AND (codeno IN
          (SELECT codeno
         FROM job_list
         WHERE d = '' AND id = @intID)) or id=@intID



        END


if   @@error=0   
COMMIT TRANSACTION
else   
rollback  TRANSACTION

RETURN 1
go

