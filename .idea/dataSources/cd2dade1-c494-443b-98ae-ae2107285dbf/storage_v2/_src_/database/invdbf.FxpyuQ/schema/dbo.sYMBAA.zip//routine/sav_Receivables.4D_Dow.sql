--exec Sav_Receivables 0,'RC','0','Admin','',''
CREATE PROCEDURE  [dbo].[sav_Receivables]
	 @BillID        int,
	 @OperateType		Varchar(4), --RC:合同周期收费生成; US:使用量收费生成;AM:金额确认收费生成;VH:槽车过磅;DD:桶装出货;IO:即灌即出;FD:灌桶;DB:库存桶;SP:来船次;SC：来船吨
	 @sno 				Varchar(8),        -- 相应单号
	 @OperatorID		Varchar(8),
	 @RetCode				int output,
	 @RetMessage		varchar(8000) Output
AS
DECLARE
   @ReceivablesID  varchar(32),
   @no char(20),
   @commodity char(15),
   @ServiceID varchar(4),
   @t_customer char(15),
   @customer char(15),
   @tank char(7),
   @OccurDate datetime,
   @Price numeric(20,6),
   @Cent numeric(20,6),
   @TaxRate numeric(20,6),
   @Remarks varchar(100),
   @Remarks1 varchar(100),
   @Date1    DateTime,
   @item_no char(15),
   @ww numeric(8,3),
   @bal numeric(8,3),
   @actual numeric(10,3),
	@PriceUnit            int,
	@Number          	    Numeric(20,6),
	@Number1          	    Numeric(20,6),
	@Number2          	    Numeric(20,6),
	@Remark           	  Varchar(100),
    @ChangesType          Int,
	@Days                 Int,
	@DayNum               int,
    @IsSiteCharge         int,
	@ReceivablesDate      DateTime,
	@IsInTrade            Bit,
	@IsOutTrade           Bit,
	@NowDate		      DateTime,
    @strUNIT_NAME VARCHAR(800),
	@st_Date         DateTime,    
	@en_Date         DateTime,    
	@chk_Date        DateTime,    
	@c_Date        DateTime,    
	@c_Date1        DateTime,    
    @ChargeType          Int,
    @name                varchar(64),
	@t_day int,
	@s_day int,
	@t_num  Numeric(20,6),
	@quantity  Numeric(10,3),
	@amount    Numeric(15,2),
	@Plan_no  Varchar(8),
	@netweight  Numeric(6,0),
	@drums     Numeric(4,0),
	@packing     Numeric(4,0),
	@jobno  Varchar(8),
	@jzx int,
	@code Varchar(12),
	@balance Numeric(7,0),
	@outremarks varchar(100),
	@min_input  Numeric(7,0),
	@crcinput  Numeric(11,3),
	@ttdcinput  Numeric(11,3),
	@crcinput1  Numeric(11,3),
	@ttdcinput1  Numeric(11,3),
	@miniquan   Numeric(12,3),
	@freequan  Numeric(12,3),
	@Isnum            Bit,
	@s varchar(100),@a varchar(3),@b varchar(3),
	@fee_date DateTime,

	@ROWS				INT,  
	@ROW1				INT  

 	set @IsSiteCharge	=0
	if isnull(@OperateType,'')=''
		set @OperateType='RC' 
	if isnull(@OperatorID,'')=''
		set @OperatorID='Admin' 
	set @NowDate=Getdate()

/*
處理update 的部分
*/
BEGIN TRANSACTION                                       
     IF @OperateType='RC' --exec Sav_Receivables 0,'RC',0,'Admin','',''   周期结算部分 billid为0时，自动计算当日到期合同，为2001~2012(YYMM)时，计算当月合同

     BEGIN
		if @BillID=0
		begin  
		Declare Getcontractlist cursor static for 
			SELECT   a.id,  a.st_date, a.en_date, a.chk_date, b.tank, a.customer,d.commodity,
					 b.serviceid, b.price,c.ChargeType, c.Name,GETDATE() as c_date,32-DAY(GETDATE()-DAY(GETDATE())+32) as t_day,datediff(dd , GETDATE(),en_date) as s_day,
					 'RC'+substring(rtrim(cast(a.id+100 as varchar)),2,2)+rtrim(b.serviceid)+CONVERT(varchar(12) , getdate(), 12 )+substring(rtrim(cast(d.showid+100 as varchar)),2,2) as no
			FROM      contract AS a ,
					contractlist AS b ,
					Service AS c ,contracttank as d
			WHERE   (a.en_date >= GETDATE()) AND (ISNULL(a.d, ' ') = ' ') AND (DAY(a.chk_date) = datename(dd,GETDATE())) AND (ISNULL(b.D, ' ') = ' ') AND 
					(c.ChargeType = 1)   and a.id=b.billid and b.serviceid=c.serviceid and (b.tank=d.tank and a.id=d.billid and (ISNULL(d.D, ' ') = ' '))				
		end
		else
		begin
		set @date1=CAST(('20'+SUBSTRING(cast(@BillID as varchar(4)),1,2)+'-'+SUBSTRING(cast(@BillID as varchar(4)),3,2)+'-'+'01') AS DATETIME) 
		Declare Getcontractlist cursor static for 
		select id,St_date,En_date,Chk_date,Tank,customer,commodity,ServiceId,price,chargetype,name,c_date,32-DAY(c_date-DAY(c_date)+32) as t_day,datediff(dd ,c_date,en_date)+1 as s_day, 
		      'RC'+substring(rtrim(cast(id+100 as varchar)),2,2)+rtrim(serviceid)+CONVERT(varchar(12) , c_date, 12 )+substring(rtrim(cast(showid+100 as varchar)),2,2) as no
		from  
		(SELECT   a.id,  a.st_date, a.en_date, a.chk_date, b.tank, a.customer,d.commodity,
				 b.serviceid, b.price,c.ChargeType, c.Name,CAST(datename(YYYY,@date1)+'-'+datename(MM,@date1)+'-'+datename(DD,a.chk_date) AS DATETIME) as c_date,d.showid
			FROM      contract AS a ,
					contractlist AS b ,
					Service AS c ,contracttank as d
			WHERE   (a.en_date > @date1) AND (a.st_date < @date1) and  (ISNULL(a.d, ' ') = ' ') AND  (ISNULL(b.D, ' ') = ' ') AND 
							(c.ChargeType = 1)   and a.id=b.billid and b.serviceid=c.serviceid and (b.tank=d.tank and a.id=d.billid and (ISNULL(d.D, ' ') = ' '))
							) as cont1
		end 
		SET @ROW1=0	
		open  Getcontractlist
		--提取游标
		fetch First from Getcontractlist into @Billid,@St_date,@En_date,@Chk_date,@Tank,@customer,@commodity,@ServiceId,@price,@chargetype,@name,@c_date,@t_day,@s_day,@no
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
		 begin
		set @amount=0 
		set @Remarks=''
		set @t_num=0
		 if @ServiceID='01' --周期租罐费
		 begin
		   if (@t_day<@s_day)
		     set @t_num=1
			else 
		     set @t_num=cast(@s_day/(@t_day+0.0) as decimal(18,6))
		   set @amount=@t_num*@Price 
		 end
		 if @ServiceID='11' --周期租罐超量费
		 begin
			select @c_date1=dateadd(month,1,@c_date)
			if @c_date1<@st_date 
				set @c_date=@st_date 
			select @min_input=min_input from contracttank where billid=@BillID and tank=@tank and isnull(d,' ')=' ' 
			select @crcinput=sum(actual) from crc where date2>=@st_date and date2<@c_date1 and tank=@tank and isnull(d,' ')=' ' 
			select @ttdcinput=sum(-netweight/1000) from ttdc where date2>=@st_date and date2<@c_date1 and netweight<0 and tank=@tank and isnull(d,' ')=' ' 
			select @crcinput1=sum(actual) from crc where date2>=@c_date1 and date2<@c_date and tank=@tank and isnull(d,' ')=' ' 
			select @ttdcinput1=sum(-netweight/1000) from ttdc where date2>=@c_date1 and date2<@c_date and netweight<0 and tank=@tank and isnull(d,' ')=' ' 
		   set @crcinput=isnull(@crcinput,0)
		   set @crcinput1=isnull(@crcinput1,0)
		   set @ttdcinput=isnull(@ttdcinput,0)
		   set @ttdcinput1=isnull(@ttdcinput1,0)
		   set @Remarks='最小进货量为：'+rtrim(convert(varchar(7),@min_input))+'吨，储罐进货量截止上周期累计：'+rtrim(convert(varchar(11),@crcinput+@ttdcinput))+'吨，本周期为：'+rtrim(convert(varchar(11),@crcinput1+@ttdcinput1))+'吨'
		   if (@crcinput+@crcinput1+@ttdcinput+@ttdcinput1<@min_input)
				set @t_num=0
			else 
			begin
			if (@crcinput+@ttdcinput>=@min_input)
				set @t_num=@crcinput1+@ttdcinput1
			else
				set @t_num=@crcinput+@crcinput1+@ttdcinput+@ttdcinput1-@min_input
			end
		   set @amount=@t_num*@Price 
		 end
		if @amount<>0
		begin
			if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID )
			   begin
					--修改更新 
					update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@c_date,tank=@tank,customer=@customer,commodity=@commodity,
							number=@t_num, price=@price,amount=@amount,OperatorID=@OperatorID,Remarks=@Remarks
					where no=@no and serviceid=@ServiceID
				end
			else
				begin 
					--新增
 					EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
					set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
					Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,Remarks) 
								values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@c_date,GETDATE(),@t_num,@Price,@amount,@OperatorID,@remarks)
				end
		    end
			fetch next from Getcontractlist into @Billid,@St_date,@En_date,@Chk_date,@Tank,@customer,@commodity,@ServiceId,@price,@chargetype,@name,@c_date,@t_day,@s_day,@no
		 end  

		close Getcontractlist --关闭游标 
		Deallocate Getcontractlist--释放游标

	 end 

	 IF @OperateType='US'  --exec Sav_Receivables 0,'US','000012','Admin','',''   使用量费用结算部分
     BEGIN

		SELECT  @nowdate=date,@no='US'+useno,@customer=customer,@BillID=billid,@ServiceID=serviceid,@quantity=quantity,
		@price=price,@TaxRate=taxrate,@Remarks=remarks,@miniquan=miniquan,@freequan=freequan,@isnum=isnum
		FROM      vw_usequantity
		WHERE   useno = @sno   
		if @freequan>0 
		begin	
			set @quantity=@quantity-@freequan
			set @remarks=rtrim(@remarks)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
		end
		if @quantity-@miniquan<0
		begin
			set @quantity=@miniquan
			set @remarks=rtrim(@remarks)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
		end
		if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID )
		   begin
				--修改更新 
				update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,price=@price,number=@quantity,amount=(@Price)*(@quantity),
				OperatorID=@OperatorID,remarks=@remarks
				where no=@no and serviceid=@ServiceID
			end
		else
			begin 
				--新增
 				EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
				set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
				Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,OccurDate,CreateDate, price,Number,amount,OperatorID,remarks) 
						  values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@nowdate,GETDATE(),@Price,@quantity,(@Price)*(@quantity),@OperatorID,@remarks)
			end

	 end 

	 IF @OperateType='AM'  --exec Sav_Receivables 0,'AM','000012','Admin','',''   金额确认费用结算部分
     BEGIN

		SELECT  @nowdate=date,@no='AM'+amountno,@customer=customer,@BillID=billid,@ServiceID=serviceid,@amount=amount,
		@price=price,@TaxRate=taxrate,@Remarks=remarks
		FROM      vw_amount
		WHERE   amountno = @sno   
		if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID )
		   begin
				--修改更新 
				update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,price=@price,amount=@amount,
						OperatorID=@OperatorID,remarks=@remarks
				where no=@no and serviceid=@ServiceID
			end
		else
			begin 
				--新增
 				EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
				set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
				Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,OccurDate,CreateDate, price,amount,OperatorID,remarks) 
						  values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@nowdate,GETDATE(),@Price,@amount,@OperatorID,@remarks)
			end

	 end 

	 IF @OperateType='VH'  --exec Sav_Receivables 0,'VH','002222','Admin','',''   槽车装卸收费结算部分
     BEGIN

		SELECT  @nowdate=date2,@Plan_no=plan_no,@BillID=billid,@customer=t_customer,@commodity=commodity,@tank=tank,@no='VH'+ttdc_no,@Remarks=remarks,@netweight=netweight
		FROM   ttdc
		WHERE   ttdc_no = @sno 
		--确定合同号代码
		if rtrim(@plan_no)<>'' or left(ltrim(rtrim(@tank)),1)='I' 
			begin
				select @billid=billid from vehi_plan  where plan_no=@Plan_no and isnull(d,' ')=' '
				update ttdc set billid=@BillID where ttdc_no=@sno and isnull(d,' ')=' '
			end 
		else
			begin
				select @billid=id from contract 
				where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
				order by st_date 
				update ttdc set billid=@BillID where ttdc_no=@sno and isnull(d,' ')=' '
			end 
		--查询合同相关收费项目
		Declare Getcontractservicelist cursor static for 
		SELECT   billid, serviceid,  price,miniquan,freequan,isnum
		FROM      Vw_contractservice
		WHERE   (billid = @BillID) AND (serviceid IN ('02', '14', '15'))	  
		SET @ROW1=0	
		open  Getcontractservicelist
		--提取游标
		fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin
				if @ServiceID='02' --按车次计费，装卸车
					set @Number=1
				else
					begin
						if @ServiceID ='14' and @netweight <0 --按吨数计费，卸车
							set @Number=-@netweight/1000
						else
							begin 
								if @ServiceID ='15' and @netweight >0  --按吨数计费，装车
									set @Number=@netweight
								else 
									set @Number=0
							end 
					end 
				if @Number>0 
				begin 
					if @freequan>0 
					begin	
						set @Number=@Number-@freequan
						set @remarks=rtrim(@remarks)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
					end
					if @Number-@miniquan<0
					begin
						set @Number=@miniquan
						set @remarks=rtrim(@remarks)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
					end
				end
				set @amount=@Number*@Price
				if @amount<>0
				begin 
					if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID ) 
					   begin
							--修改更新 
							update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
									number=@netweight/1000, price=@price,amount=@amount,
									OperatorID=@OperatorID,remarks=@remarks
							where no=@no and serviceid=@ServiceID
						end
					else
						begin 
							--新增
 							EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
							set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
							Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate,number, price,amount,OperatorID,remarks) 
									  values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@remarks)
						end
				end 
		    fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
			end 
		close Getcontractservicelist --关闭游标 
		Deallocate Getcontractservicelist--释放游标
	end 

	 IF @OperateType='DB'  --exec Sav_Receivables 0,'DB','0','Admin','',''   库存桶收费结算部分
     BEGIN
		set @nowdate=GETDATE()
		set @fee_date=dateadd(ms,-3,DATEADD(mm, DATEDIFF(m,0,@NowDate-10)+1, 0)) 
		set @remarks1=''
		set @t_day=0
		Declare Getdrums cursor static for
		SELECT  code1+code2 as code,balance , 'DB'+code1+code2+CONVERT(varchar(12) , getdate(), 12 ) as no,billid,t_customer,c_customer,commodity,tank ,packing
		FROM   drums
		WHERE   balance >0 
		order by date
		open  Getdrums
		--提取游标
		fetch First from Getdrums into @code,@balance,@no,@billid,@t_customer,@customer,@commodity,@tank,@packing
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
		begin
			--确定合同号代码
			if @billid=0 
			begin
				select top 1 @billid=billid from fdm where code1+code2 = @code and isnull(d,' ')=' ' order by date desc
				update drums set billid=@BillID where code1+code2 = @code and balance>0
				print @billid
			end 
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('34','39','44'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
						--set @remarks1=@remarks
							set @number=0
							set @Number1=0
 							set @Number2=0
 							EXEC sav_drums_date_month @code,@fee_date=@fee_date,@serviceid=@serviceid,@output=@outremarks OUTPUT
							print @serviceid
							--print @jobno
							if @outremarks<>''
								begin
								set @s=@outremarks
								WHILE CHARINDEX(';',@s)>0
									begin
										print CHARINDEX('天;',@s)-CHARINDEX('桶:',@s)
										SELECT @a=substring(@s,1, CHARINDEX('桶:',@s)-1) ,@b=substring(@s,CHARINDEX('桶:',@s)+2, CHARINDEX('天;',@s)-CHARINDEX('桶:',@s)-2) , @S=STUFF(@S,1,CHARINDEX(';',@s),'')
										set @Number = @Number+ cast(@a as decimal(6,0)) *CAST(@b as decimal(6,0))
										set @Number1 = @Number1+ cast(@a as decimal(6,0)) *FLOOR(CAST(@b as decimal(6,0))/7)
										set @Number2 = @Number2+ cast(@a as decimal(6,0)) *CAST(@b as decimal(6,0))*@packing /1000
									END
								end
							if @ServiceID ='34'  --桶存放费按桶天计费
								set @Number=@Number
							else 
								begin
								if  @ServiceID ='39'  --桶存放费按桶周计费，不到一周按一周算
									set @Number=@Number1
								else
									begin
									if @ServiceID ='44'  --桶存放费按吨天计费，不到一周按一周算
										set @Number=@Number2
									else
										set @Number=0
									end
								end
						--print @number
						--print @outremarks
						set @Remarks1=@outremarks
						--print @amount
						print @remarks1
						set @amount=@Number*@Price
						print @number
						print @amount
						if @amount<>0
						begin 
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID ) 
							begin
								--修改更新 
								update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@fee_date,tank=@tank,customer=@customer,commodity=@commodity,
										number=@Number, price=@price,amount=@amount,
										OperatorID=@OperatorID,remarks=@Remarks1
								where no=@no and serviceid=@ServiceID
								update drums set date_fee=@fee_date where code1+code2=@code
							end
						else
							begin 
								--新增
 								EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
								set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
								Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
											values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@fee_date,GETDATE(),@Number,@Price,@amount,@OperatorID,@Remarks1)
								update drums set date_fee=@fee_date where code1+code2=@code
							end
					end
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				end
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
				fetch next from Getdrums into @code,@balance,@no,@billid,@t_customer,@customer,@commodity,@tank,@packing
		end 
		close Getdrums --关闭游标 
		Deallocate Getdrums--释放游标
	 end
	  


	 IF @OperateType='DD'  --exec Sav_Receivables 0,'DD','002222','Admin','',''   桶车装卸收费结算部分
     BEGIN
		Declare Getddc cursor static for
		SELECT  date2,plan_no,billid,t_customer,c_customer,commodity,tank,'DD'+ddc_no+right(ltrim(rtrim(jobno)),2),remarks,netweight,drums,packing,jobno ,
			(case when ((charindex('叉车装箱',remarks)>0 or  charindex('集装箱',remarks)>0 ) and charindex('20尺',remarks)>0) then 1 
			      when ((charindex('叉车装箱',remarks)>0 or  charindex('集装箱',remarks)>0 ) and charindex('40尺',remarks)>0) then 2
			      when ((charindex('叉车装箱',remarks)>0 or  charindex('集装箱',remarks)>0 ) and (charindex('20尺',remarks)=0 or charindex('40尺',remarks)=0)) then 1
				  else 0 end) as JZX
		FROM   ddc
		WHERE   ddc_no = @sno 
		order by jobno
		open  Getddc
		--提取游标
		fetch First from Getddc into @nowdate,@Plan_no,@BillID,@t_customer,@customer,@commodity,@tank,@no,@Remarks,@netweight,@drums,@packing,@jobno,@jzx 
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin 
				--确定合同号代码
				if rtrim(@plan_no)<>'' 
					begin
						select @billid=billid from vehi_plan  where plan_no=@Plan_no and isnull(d,' ')=' '
						update ddc set billid=@BillID where jobno=@jobno and isnull(d,' ')=' '
					end 
				else
					begin
						print @jobno
						print @tank
						if ltrim(rtrim(@tank))='' or left(ltrim(@tank),1)='I'  or ltrim(rtrim(@t_customer))<>ltrim(rtrim(@customer))
							begin
								select @billid=id from contract 
								where customer=@customer and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
								order by st_date
							end
						else
							begin
								select @billid=id from contract 
								where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
								order by st_date
							end	 
						update ddc set billid=@BillID where jobno=@jobno and isnull(d,' ')=' '
					end 
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('31', '33', '34','39','42','43','44'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
						print @serviceid
						set @remarks1=@remarks
						if @ServiceID='31' --按桶数计费，普通装卸车
							set @number=@drums
						else
						begin
							if @ServiceID ='33' and @jzx <>0 --按桶数计费，集装箱装卸车
								set @number=@drums
							else
								begin
								if (@ServiceID ='42' and @jzx =1) or (@ServiceID ='43' and @jzx =2) --按箱计费，20英尺/40英尺集装箱装卸车
									begin
										set @number=1
										set @Remarks1=rtrim(@Remarks1)+'装'+str(@jzx*20)+'英尺集装箱;'
									end
								else
									begin 
									set @number=0
									set @Number1=0
 									set @Number2=0
									EXEC sav_drums_date @t_no=@jobno ,@output=@outremarks OUTPUT
									print @outremarks
									print @jobno
									if @outremarks<>''
										begin
										set @s=@outremarks
										WHILE CHARINDEX(';',@s)>0
											begin
												print CHARINDEX('天;',@s)-CHARINDEX('桶:',@s)
												SELECT @a=substring(@s,1, CHARINDEX('桶:',@s)-1) ,@b=substring(@s,CHARINDEX('桶:',@s)+2, CHARINDEX('天;',@s)-CHARINDEX('桶:',@s)-2) , @S=STUFF(@S,1,CHARINDEX(';',@s),'')
												set @Number = @Number+ cast(@a as decimal(6,0)) *CAST(@b as decimal(6,0))
												set @Number1 = @Number1+ cast(@a as decimal(6,0)) *CEILING(CAST(@b as decimal(6,0))/7)
												set @Number2 = @Number2+ cast(@a as decimal(6,0)) *CAST(@b as decimal(6,0))*@packing /1000
											END
										end
									if @ServiceID ='34' and @netweight >0  --桶存放费按桶天计费
										set @Number=@Number
									else 
										begin
										if  @ServiceID ='39' and @netweight >0 --桶存放费按桶周计费，不到一周按一周算
											set @Number=@Number1
										else
											begin
											if @ServiceID ='44' and @netweight >0 --桶存放费按吨天计费，不到一周按一周算
												set @Number=@Number2
											else
												set @Number=0
											end
										end
									end 
							end
							print @outremarks
							set @Remarks1=Rtrim(@Remarks1)+@outremarks
							--print @amount
						end	
						if @Number>0 
						begin 
							if @freequan>0 
							begin	
								set @Number=@Number-@freequan
								set @remarks1=rtrim(@remarks1)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
							end
							if @Number-@miniquan<0
							begin
								set @Number=@miniquan
								set @remarks1=rtrim(@remarks1)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
							end
						end
						set @amount=@Number*@Price
						print @number
						print @amount
						if @amount<>0
						begin 
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID ) 
							begin
								--修改更新 
								update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
										number=@Number, price=@price,amount=@amount,
										OperatorID=@OperatorID,remarks=@Remarks1
								where no=@no and serviceid=@ServiceID
							end
						else
							begin 
								--新增
 								EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
								set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
								Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
											values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@Remarks1)
							end
					end
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				end
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
				fetch next from  Getddc into @nowdate,@Plan_no,@BillID,@t_customer,@customer,@commodity,@tank,@no,@Remarks,@netweight,@drums,@packing,@jobno,@jzx  
			end
		close Getddc --关闭游标 
		Deallocate Getddc--释放游标
	end 

	 IF @OperateType='IO'  --exec Sav_Receivables 0,'IO','002222','Admin','',''   即灌即出装卸收费结算部分
     BEGIN
		Declare Getfifo cursor static for
		SELECT  date2,plan_no,billid,customer,commodity,tank,'IO'+no,remarks,drums_out,packing,jobno
		FROM   drm_fifo
		WHERE   no = @sno 
		order by jobno
		open  Getfifo
		--提取游标
		fetch First from Getfifo into @nowdate,@Plan_no,@BillID,@customer,@commodity,@tank,@no,@Remarks,@drums,@packing,@jobno 
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin 
				--确定合同号代码
				if rtrim(@plan_no)<>'' 
					begin
						select @billid=billid from vehi_plan  where plan_no=@Plan_no and isnull(d,' ')=' '
						update drm_fifo set billid=@BillID where jobno=@jobno and isnull(d,' ')=' '
					end 
				else
					begin
						if ltrim(rtrim(@tank))='' or left(ltrim(rtrim(@tank)),1)='I' 
							begin
								select @billid=id from contract 
								where customer=@customer and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
								order by st_date
							end
						else
							begin
								select @billid=id from contract 
								where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
								order by st_date
							end	 
						update drm_fifo set billid=@BillID where jobno=@jobno and isnull(d,' ')=' '
					end 
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('27','28','29', '32'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
						set @Remarks1=@Remarks
						if @ServiceID='27' and @packing <=400--按桶数计费，普通灌桶费
						begin
							set @number=@drums
							set @Remarks1=rtrim(@Remarks1)+'灌标准桶；'
						end
						else
						begin
							if @ServiceID ='28' and @packing >800 --按桶数计费，IBC灌桶
							begin
								set @number=@drums
								set @Remarks1=rtrim(@Remarks1)+'灌IBC桶；'
							end
							else
							begin
								if @ServiceID ='29' and left(@tank,1)='I' --按桶数计费，isotank灌桶
								begin
									set @number=@drums
									set @Remarks1=rtrim(@Remarks1)+'ISOTANK灌桶；'
								end
								else
								begin
									if @ServiceID ='32' and left(@tank,1)='I' --按桶数计费，isotank灌桶
									begin
										set @number=@drums
										set @Remarks1=rtrim(@Remarks1)+'贴标签；'
									end
									else
									begin
										set @number=0
										set @Remarks1=''
									end
								end
							end
						end
						if @Number>0 
						begin 
							if @freequan>0 
							begin	
								set @Number=@Number-@freequan
								set @remarks1=rtrim(@remarks1)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
							end
							if @Number-@miniquan<0
							begin
								set @Number=@miniquan
								set @remarks1=rtrim(@remarks1)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
							end
						end
						print @serviceid
						print @no
						print @number
						set @amount=@Number*@Price
						--set @Remarks1=rtrim(@Remarks1)+@outremarks
						--print @amount
						if @amount<>0
						begin 
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID ) 
							begin
								--修改更新 
								update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
										number=@Number, price=@price,amount=@amount,
										OperatorID=@OperatorID,remarks=@remarks1
								where no=@no and serviceid=@ServiceID
							end
						else
							begin 
								--新增
 								EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
								set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
								Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
											values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@remarks1)
							end
						end
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
					end 
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
				fetch next from  Getfifo into @nowdate,@Plan_no,@BillID,@customer,@commodity,@tank,@no,@Remarks,@drums,@packing,@jobno
			end
		close Getfifo --关闭游标 
		Deallocate Getfifo--释放游标
	end 

	 IF @OperateType='FD'  --exec Sav_Receivables 0,'FD','002222','Admin','',''   灌桶收费结算部分
     BEGIN
		Declare Getfdm cursor static for
		SELECT  date,t_customer,c_customer,commodity,tank,'FD'+no,remarks,drums,packing,job_no 
		FROM   fdm
		WHERE   no = @sno 
		order by job_no
		open  Getfdm
		--提取游标
		fetch First from Getfdm into @nowdate,@t_customer,@customer,@commodity,@tank,@no,@Remarks,@drums,@packing,@jobno 
		print @jobno
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin 
				--确定合同号代码
				if ltrim(rtrim(@tank))='' or left(ltrim(rtrim(@tank)),1)='I'  or @t_customer<>@customer
					begin
						select @billid=id from contract 
						where customer=@customer and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end
				else
					begin
						select @billid=id from contract 
						where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end	 
				print @billid
				update fdm set billid=@BillID where job_no=@jobno and isnull(d,' ')=' '
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('27','28','29','30', '32'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
						set @Remarks1=@Remarks
						if @ServiceID='27' and @packing <=400--按桶数计费，普通灌桶费
						begin
							set @number=@drums
							set @Remarks1=rtrim(@Remarks1)+'灌标准桶；'
						end
						else
						begin
							if @ServiceID ='28' and @packing >800 --按桶数计费，IBC灌桶
							begin
								set @number=@drums
								set @Remarks1=rtrim(@Remarks1)+'灌IBC桶；'
							end
							else
							begin
								if @ServiceID ='29' and left(@tank,1)='I' --按桶数计费，isotank灌桶
								begin
									set @number=@drums
									set @Remarks1=rtrim(@Remarks1)+'ISOTANK灌桶；'
								end
								else
								begin
									if @ServiceID ='32' or  @ServiceID ='30' --按桶数计费
									begin
										set @number=@drums
									end
									else
										set @number=0
								end
							end
						end
						if @Number>0 
						begin 
							if @freequan>0 
							begin	
								set @Number=@Number-@freequan
								set @remarks1=rtrim(@remarks1)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
							end
							if @Number-@miniquan<0
							begin
								set @Number=@miniquan
								set @remarks1=rtrim(@remarks1)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
							end
						end
						set @amount=@Number*@Price
						--set @Remarks1=rtrim(@Remarks1)+@outremarks
						print @amount
						if @amount<>0
						begin 
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and serviceid=@ServiceID ) 
							begin
								--修改更新 
								update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
										number=@Number, price=@price,amount=@amount,
										OperatorID=@OperatorID,remarks=@remarks1
								where no=@no and serviceid=@ServiceID
							end
						else
							begin 
								--新增
 								EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
								set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
								Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
											values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@remarks1)
							end
						end
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
					end
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
				fetch next from  Getfdm into @nowdate,@t_customer,@customer,@commodity,@tank,@no,@Remarks,@drums,@packing,@jobno
			end
		close Getfdm --关闭游标 
		Deallocate Getfdm--释放游标
	end 
	 IF @OperateType='SP'  --exec Sav_Receivables 0,'SP','002222','Admin','',''   来船收费结算部分(次数)
     BEGIN
		Declare GetSHIP cursor static for
		SELECT  date1,date2,customer,commodity,'SP'+ship_no,item_no,remarks,ww,bal 
		FROM   Vw_ship
		WHERE   ship_no = @sno 
		order by ship_no
		set @amount=0
		open  GetSHIP
		fetch First from GetSHIP into @date1,@nowdate,@customer,@commodity,@no,@item_no,@Remarks ,@ww,@bal
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin 
				set @tank=''
				--确定合同号代码
				if ltrim(rtrim(@tank))='' or left(ltrim(rtrim(@tank)),1)='I' 
					begin
						select @billid=id from contract 
						where customer=@customer and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end
				else
					begin
						select @billid=id from contract 
						where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end	 
				print @billid
				update shiprec set billid=@BillID where item_no=@item_no and customer=@customer and cargo=@commodity and isnull(d,' ')=' '
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('08','19','22','23', '24'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
					set @Remarks1=rtrim(@Remarks)
					if @ServiceID='08' or @ServiceID='19' --装卸船、管输，按船计费
					begin
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and customer=@customer and serviceid=@ServiceID ) 
							set @number=0
						else
							set @Number=1
						set @Remarks1=rtrim(@Remarks1)+'按船结算；'
					end
					else
					begin
						if @ServiceID='22' or @ServiceID='23' or @ServiceID='24' --申报、报关、换单，按货品计费
						begin
							if @Isnum=1
							begin
								if @bal>=@freequan and @bal<@miniquan
								begin
									set @Number=1
									set @Remarks1=rtrim(@Remarks1)+'按货品数结算,来船量（'+ltrim(rtrim(str(@bal)))+'）阶梯量计算（'+ltrim(rtrim(str(@freequan)))+'）；'
								end
								else
								begin
									set @number=0
									set @Remarks1=''
								end 	
							end
							else
							begin	
								set @Number=1
								set @Remarks1=rtrim(@Remarks1)+'按货品数结算；'
							end 
						end
						else
						begin
							set @number=0
							set @Remarks1=''
						end	
					end	
					set @amount=@Number*@Price
					print @amount
					if @amount<>0
					begin 
					if exists( select ReceivablesID from Vw_Receivables  where no=@no and customer=@customer and commodity=@commodity and serviceid=@ServiceID ) 
						begin
							--修改更新 
							update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
									number=@Number, price=@price,amount=@amount,
									OperatorID=@OperatorID,remarks=@remarks1
							where no=@no and customer=@customer and commodity=@commodity and serviceid=@ServiceID
						end
					else
						begin 
							--新增
 							EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
							set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
							Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
										values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@remarks1)
						end
					end
					
					
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
					end 
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
			fetch Next from GetSHIP into @date1,@nowdate,@customer,@commodity,@no,@item_no,@Remarks ,@ww,@bal

			end 
		close Getship --关闭游标 
		Deallocate Getship--释放游标
	 end
	 IF @OperateType='SC'  --exec Sav_Receivables 0,'SC','C002222','Admin','',''   来船收费结算部分(吨)
     BEGIN
		Declare GetSHIPCRC cursor static for
		SELECT  date1,date2,c_customer,commodity,tank,'SC'+no as no1,item_no,remarks,actual
		FROM   Vw_shipcrc
		WHERE   no = @sno 
		order by no1
		set @amount=0
		open  GetSHIPCRC
		fetch First from GetSHIPCRC into @date1,@nowdate,@customer,@commodity,@tank,@no,@item_no,@Remarks ,@actual
		while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
			begin 
				--确定合同号代码
				if ltrim(rtrim(@tank))='' 
					begin
						select @billid=id from contract 
						where customer=@customer and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end
				else
					begin
						select @billid=id from contract 
						where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@NowDate and en_date>=@NowDate and isnull(d,' ')=' '
						order by st_date
					end	 
				if left(@sno,1)='C'
					update crc set billid=@BillID where crc_no=SUBSTRING(@sno,2,len(@sno)-1) and isnull(d,' ')=' '
				else
					update [bulk] set billid=@BillID where bulk_no=SUBSTRING(@sno,2,len(@sno)-1) and isnull(d,' ')=' '
				--查询合同相关收费项目
				Declare Getcontractservicelist cursor static for 
				SELECT   billid, serviceid,  price,miniquan,freequan,isnum
				FROM      Vw_contractservice
				WHERE   (billid = @BillID) AND (serviceid IN ('12','13','16','17', '18','20','21','36','48'))	  
				SET @ROW1=0	
				open  Getcontractservicelist
				--提取游标
				fetch First from Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
					begin
					set @Remarks1=rtrim(@Remarks)
					if @ServiceID='20' or @ServiceID='21' or @ServiceID='36' or @ServiceID='48' --港口设施、港建、港口服务、商检费，按吨计费
					begin
						set @Number=@actual
					end
					else
					begin
						if @ServiceID='12' and  left(@sno,1)='C'--卸船，按吨计费
						begin
							set @Number=@actual
						end
						else
						begin
							if @ServiceID='13' and  left(@sno,1)='B'--装船，按吨计费
								set @Number=@actual
							else
								set @Number=0
						end	 
						if @Number>0 
						begin 
							if @freequan>0 
							begin	
								set @Number=@Number-@freequan
								set @remarks1=rtrim(@remarks1)+'  减免量为:'+ltrim(rtrim(str(@freequan)))+';'
							end
							if @Number-@miniquan<0
							begin
								set @Number=@miniquan
								set @remarks1=rtrim(@remarks1)+'  实际量未到最低量'+ltrim(rtrim(str(@miniquan)))+'以最低量计算;'
							end
						end
						set @amount=@Number*@Price
						print @serviceid
					if @amount<>0
						begin 
						if exists( select ReceivablesID from Vw_Receivables  where no=@no and customer=@customer and commodity=@commodity and serviceid=@ServiceID ) 
							begin
								--修改更新 
								update  Receivables set billid=@billid,serviceid=@serviceid,OccurDate=@nowdate,tank=@tank,customer=@customer,commodity=@commodity,
										number=@Number, price=@price,amount=@amount,
										OperatorID=@OperatorID,remarks=@remarks1
								where no=@no and customer=@customer and commodity=@commodity and serviceid=@ServiceID
							end
						else
							begin 
								--新增
 								EXEC	@ReceivablesID=w_no N'receivablesid',N'0',''
								set @ReceivablesID =right('000000'+convert(varchar(6),@ReceivablesID),6)
								Insert into Receivables (billid,ReceivablesID,no,ServiceID,customer,tank,commodity,OccurDate,CreateDate, number,price,amount,OperatorID,remarks) 
											values (@BillID,@ReceivablesID,@no,@ServiceID,@customer,@tank,@commodity,@nowdate,GETDATE(),@Number,@Price,@amount,@OperatorID,@remarks1)
							end
						end
					
					end
					
					fetch next from  Getcontractservicelist into @Billid,@ServiceId,@price,@miniquan,@freequan,@isnum
					end 
				close Getcontractservicelist --关闭游标 
				Deallocate Getcontractservicelist--释放游标
			fetch Next from GetSHIPCRC into @date1,@nowdate,@customer,@commodity,@tank,@no,@item_no,@Remarks ,@actual

			end 
		close GetshipCRC --关闭游标 
		Deallocate GetshipCRC--释放游标
	 end
if   @@error=0   
	COMMIT TRANSACTION
else   
	rollback  TRANSACTION


go

