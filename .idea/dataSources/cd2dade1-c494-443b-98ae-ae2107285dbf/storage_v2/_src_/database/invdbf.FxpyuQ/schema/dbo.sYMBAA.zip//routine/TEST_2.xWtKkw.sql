CREATE PROCEDURE TEST_2

@strTO VARCHAR(6)

AS

DECLARE

 @strUNIT_NAME VARCHAR(800),

 @strSQL VARCHAR(8000),

 @Link VARCHAR(1),

 @Link1 VARCHAR(1)

 

SET @strUNIT_NAME=''

SET @strSQL=''

SET @Link=''

SET @Link1=''

 

/*

處理update 的部分

EXEC TEST_2 '011'

EXEC TEST_2 ''

SELECT UNIT_NAME FROM UNIT WHERE UNIT_CODE='011'

*/

BEGIN TRANSACTION                                       

         IF @strTO<>''

        BEGIN

	 INSERT INTO job_list ( codeno, codeno1, content, m_scan, orderno, permission, job_no)	SELECT codeno, codeno1, content, m_scan, orderno, permission, 
	     'T'+@strTO  AS job_no
	FROM truck_code 
WHERE (tank IN
          (SELECT tank
         FROM ttdctemp
         WHERE d = '' AND jobno = @strTO)) AND (station IN
          (SELECT c_station
         FROM ttdctemp
         WHERE d = '' AND jobno = @strTO))

        END


if   @@error=0   
COMMIT TRANSACTION
else   
rollback  TRANSACTION

RETURN 1
go

