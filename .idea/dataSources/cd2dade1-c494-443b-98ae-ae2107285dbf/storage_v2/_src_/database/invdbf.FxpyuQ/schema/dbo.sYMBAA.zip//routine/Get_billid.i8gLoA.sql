

CREATE PROCEDURE  [dbo].[Get_billid]
@customer VARCHAR(20),
@tank VARCHAR(6),
@date1 datetime
--@output int output
AS
DECLARE
 @billid int;

 
/*
處理update 的部分
*/
BEGIN TRANSACTION  
	set @billid=0 
	if ltrim(rtrim(@tank))='' or left(ltrim(rtrim(@tank)),1)='I' 
		begin
			select @billid=id from contract 
			where customer=@customer and st_date<=@Date1 and en_date>=@date1 and isnull(d,' ')=' '
			order by st_date
		end
	else
		begin
			select @billid=id from contract 
			where customer=@customer and charindex(ltrim(rtrim(@tank)),tank)>0 and st_date<=@Date1 and en_date>=@date1 and isnull(d,' ')=' '
			order by st_date
		end	 
	print @billid
if   @@error=0   
	COMMIT TRANSACTION
else   
	rollback  TRANSACTION
select @billid as billid
RETURN @billid



go

