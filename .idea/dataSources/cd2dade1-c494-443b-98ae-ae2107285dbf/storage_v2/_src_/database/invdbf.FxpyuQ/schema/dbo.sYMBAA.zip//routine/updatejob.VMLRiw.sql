CREATE PROCEDURE  [dbo].[updatejob]
@strTO VARCHAR(6)
AS
DECLARE
 @strUNIT_NAME VARCHAR(800)
 
SET @strUNIT_NAME=''
 
/*
處理update 的部分
*/
BEGIN TRANSACTION                                       
         IF @strTO<>''
        BEGIN
	 update  job_list set d='D' where job_no= 'T'+@strTO  and d=''
	 INSERT INTO job_list ( codeno, codeno1, content, m_scan, orderno, permission, job_no)	SELECT codeno, codeno1, content, m_scan, orderno, permission, 
	     'T'+@strTO  AS job_no
	FROM truck_code 
WHERE (tank IN
          (SELECT  'T-' + SUBSTRING(tank, 3, 4) AS tank
         FROM ttdctemp
         WHERE d = '' AND jobno = @strTO AND (left(tank,1)in ('S','T')))) AND (station IN
          (SELECT c_station
         FROM ttdctemp
         WHERE d = '' AND jobno = @strTO)) AND d = ''
        END
if   @@error=0   
COMMIT TRANSACTION
else   
rollback  TRANSACTION
RETURN 1
go

