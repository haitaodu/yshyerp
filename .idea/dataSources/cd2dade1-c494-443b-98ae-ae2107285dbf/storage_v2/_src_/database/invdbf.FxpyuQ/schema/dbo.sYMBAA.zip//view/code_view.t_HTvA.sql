CREATE VIEW dbo.code_view
AS
SELECT TOP 100 PERCENT *
FROM dbo.codebar
ORDER BY id DESC
go

