CREATE VIEW dbo.Vw_service
AS
SELECT   dbo.Service.ServiceID, dbo.Service.Name, dbo.Service.Unit, dbo.Service.Price, dbo.Service.PriceUnit, 
                dbo.Service.IsDefault, dbo.Service.IsTank, dbo.Service.IsShip, dbo.Service.ChargeType, 
                dbo.Vw_chargetype.c_name AS c_chargetype, dbo.Service.OrderFace, dbo.Service.ChargeClass, dbo.Service.State, 
                dbo.Service.Remark
FROM      dbo.Service INNER JOIN
                dbo.Vw_chargetype ON dbo.Service.ChargeType = dbo.Vw_chargetype.e_name
WHERE   (ISNULL(dbo.Service.D, ' ') = ' ')
go

