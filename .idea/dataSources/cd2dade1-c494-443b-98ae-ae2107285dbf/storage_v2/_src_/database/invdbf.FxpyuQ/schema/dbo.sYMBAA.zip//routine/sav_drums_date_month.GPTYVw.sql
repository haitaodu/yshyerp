



CREATE PROCEDURE  [dbo].[sav_drums_date_month]
@code VARCHAR(12)='0',
@fee_date datetime,
@ServiceID varchar(4),
@output VARCHAR(100) output
AS
DECLARE
 @l_sql nVARCHAR(800),
 @Month varchar(6),
 @Month1 varchar(6),
 @no VARCHAR(8),
 @status VARCHAR(6),
 @fdmdate datetime,
 @date2 datetime,
 @date_fee datetime,
 @c_date datetime,
 @day int,
 @c_day int,
 @f_day int,
 @f_day1 int,
 @tank varchar(7),
 @t_customer varchar(15),
 @c_customer varchar(15),
 @commodity varchar(15),
 @new varchar(3),
 @color varchar(12),
 @cover bit,
 @tare  Numeric(4,1),
 @type varchar(1),
 @drums int,
 @fdmdrums int,
 @balance int
 set @output=''




/*
處理月结桶库存存放费 的部分 EXEC sav_drums_date_month @code=@code,@fee_date=@fee_date,@serviceid=@serviceid,@output=@outremarks OUTPUT
*/
BEGIN TRANSACTION   
	if isnull(@code,' ')=' ' 
		return 0 
    else
		begin
			set @Month=CONVERT(varchar(6) , @fee_date, 112 )
			set @Month1=CONVERT(varchar(6) , DATEADD(mm, DATEDIFF(mm,0,@fee_date)-1, 0), 112 )
			set @date2=@fee_date
			set @c_day=0
			set @f_day=0
			set @f_day1=0
			select @balance=balance,@date_fee=date_fee from drums where code1+code2=@code
			IF @date_fee<@fee_date
			begin 
				Declare Getfdm1 cursor static for
				SELECT  date,drums,no
				FROM   fdm
				WHERE   code1+code2 = @code and isnull(d,' ')=' '
				order by date desc 
				open  Getfdm1
				--提取游标
				fetch First from Getfdm1 into @fdmdate,@fdmdrums,@no
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
				begin
					select @day=datediff(dd , dateadd(mm, -1,@fee_date), @fee_date)
					if exists(select f_day from fdm_info where no=@no and fee_month=@Month1)
						select @f_day1=f_day from fdm_info where no=@no and fee_month=@Month1

					begin 
						if @fdmdate>@date_fee ---灌桶后桶库存已月结，则以月结时间起算
							set @c_date =convert(datetime,CONVERT(varchar(10),@fdmdate, 120 ))
						else
							set @c_date = convert(datetime,CONVERT(varchar(10),@date_fee, 120 ))
						if @balance<@fdmdrums
						begin
							if @ServiceID ='39'
							begin
								set @c_day=datediff(dd ,@c_date,@date2)+@f_day1
								set @day=@day+@f_day1
							end 
							else
								set @c_day=datediff(dd ,@c_date,@date2)
							if @c_day<@day
							begin
								set @output=@output+rtrim(ltrim(cast(@balance as varchar)))+'桶:'+rtrim(ltrim(cast(@c_day as varchar)))+'天;'
								set @f_day=CAST(@c_day as decimal(6,0))-FLOOR(CAST(@c_day as decimal(6,0))/7)*7
							end
							else
							begin
								set @output=@output+rtrim(ltrim(cast(@balance as varchar)))+'桶:'+rtrim(ltrim(cast(@day as varchar)))+'天;'
								set @f_day=CAST(@day as decimal(6,0))-FLOOR(CAST(@day as decimal(6,0))/7)*7
							end
							set @drums=@balance
							set @balance=0
							print @output
						end
						else
						begin
							if @ServiceID ='39'
							begin
								set @c_day=datediff(dd ,@c_date,@date2)+@f_day1
								set @day=@day+@f_day1
							end 
							else
								set @c_day=datediff(dd ,@c_date,@date2)
							print @c_day
							if @c_day<@day
							begin
								set @output=@output+rtrim(ltrim(cast(@fdmdrums as varchar)))+'桶:'+rtrim(ltrim(cast(@c_day as varchar)))+'天;'
								set @f_day=CAST(@c_day as decimal(6,0))-FLOOR(CAST(@c_day as decimal(6,0))/7)*7
							end
							else
							begin
								set @output=@output+rtrim(ltrim(cast(@fdmdrums as varchar)))+'桶:'+rtrim(ltrim(cast(@day as varchar)))+'天;'
								set @f_day=CAST(@day as decimal(6,0))-FLOOR(CAST(@day as decimal(6,0))/7)*7
							end
							set @balance=@balance-@fdmdrums
							set @drums=@fdmdrums
						end 
						if @ServiceID ='39'  --桶存放费按桶周计费
						begin
							print @f_day
							if exists(select f_day from fdm_info where no=@no and fee_month=@Month)
								update fdm_info set f_day=@f_day,drums=@drums  where no=@no and fee_month=@Month
							else
								Insert into fdm_info (no,fee_month,drums,f_day)	values (@no,@month,@drums,@f_day)
						end
						if @balance=0 
							break
					end
					fetch next from  Getfdm1 into @fdmdate,@fdmdrums,@no

				end
				close Getfdm1 --关闭游标 
				Deallocate Getfdm1--释放游标
			end
		end 

if   @@error=0   
	COMMIT TRANSACTION
else   
	rollback  TRANSACTION
--RETURN @output


go

