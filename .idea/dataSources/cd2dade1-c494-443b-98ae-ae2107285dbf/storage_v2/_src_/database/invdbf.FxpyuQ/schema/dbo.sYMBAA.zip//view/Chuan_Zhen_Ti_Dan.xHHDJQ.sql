CREATE VIEW dbo.传真提单
AS
SELECT TOP 100 PERCENT *
FROM dbo.donopict where left(no,3)='FAX'
ORDER BY [no] DESC

go

