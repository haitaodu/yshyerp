


CREATE PROCEDURE [dbo].[readcrcsum]
(
@Time1 datetime,
@Time2 datetime
)
AS
 
   begin
	SELECT     c_customer, vessel,item_no, date2, COUNT(c_customer) AS crc_num	FROM crc WHERE (ISNULL(d, '') <> 'D') AND (date2 >= @time1) AND (date2 <= @time2) GROUP BY c_customer, vessel,item_no, date2
end


go

