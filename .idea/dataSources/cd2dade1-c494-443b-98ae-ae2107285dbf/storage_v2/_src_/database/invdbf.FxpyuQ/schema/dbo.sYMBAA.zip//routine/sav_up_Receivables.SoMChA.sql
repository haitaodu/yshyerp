
-- =============================================
-- Author:		<SQF,,>
-- Create date: <2020-7-22,,>
-- Description:	<应收账款确认,,>
-- =============================================
CREATE PROCEDURE [dbo].[sav_up_Receivables]
	-- 1,'000042'，200,-200,'','123123','1234567','SQF','',''
	 @P_type int, --1:更新数量确认；2：更新金额确认；3：更新开票确认；4：反审核
	 @RID       Varchar(8),
	 @cent		Numeric(20,2), 
	 @deduct	Numeric(20,2), 
	 @deduct_r	Varchar(100),
	 @invoice	Varchar(50),
	 @remarks	Varchar(100),
	 @OperatorID Varchar(8),

	 @RetCode		int output,
	 @RetMessage	varchar(8000) Output


	 AS

declare
@nstate int,
@nchargetype int
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	 IF @P_Type=1
     BEGIN
		update Receivables set state=1,Remarks=@remarks where ReceivablesID=@RID
 	    Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'数量确认',convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
	 END 
	 IF @P_Type=2
     BEGIN
		update Receivables set state=2,cent=@cent,DeductMoney=@deduct,amount=Number*price+@cent-@Deduct ,DeductReason=@deduct_r,Remarks=@remarks where ReceivablesID=@RID
 	    Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'金额确认，加成为'+convert(varchar(20),convert(decimal(18,4),@cent))+',优惠为'+convert(varchar(20),convert(decimal(18,4),@deduct)) ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
	 END 
	 IF @P_Type=3
     BEGIN
		update Receivables set state=3,InvoiceNo=@invoice,InvoiceDate=GETDATE(),Remarks=@remarks where ReceivablesID=@RID
 	    Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'开票确认，号码为'+@invoice ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
	 END 
	 IF @P_Type=4
     BEGIN
		select @nstate=state,@nchargetype=ChargeType from Vw_receivables where ReceivablesID=@RID 
		if @nstate=3
		begin
			update Receivables set state=2,InvoiceNo='',InvoiceDate='' where ReceivablesID=@RID
 			Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'开票反审核' ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
		end 
		if (@nstate=2 and (@nchargetype=1 or @nchargetype=4) )
		begin
			update Receivables set state=0,cent=0,DeductMoney=0,DeductReason='' where ReceivablesID=@RID
 			Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'金额反审核' ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
		end 
		if (@nstate=2 and (@nchargetype=2 or @nchargetype=3) )
		begin
			update Receivables set state=1,cent=0,DeductMoney=0,DeductReason='' where ReceivablesID=@RID
 			Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'金额反审核' ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
		end 
		if @nstate=1
		begin
			update Receivables set state=0 where ReceivablesID=@RID
 			Insert into receiv_hist (date,name,receivablesid,cont,station) 
		          values (GETDATE(),@operatorid,@RID,'数量反审核' ,convert(varchar(20),CONNECTIONPROPERTY('client_net_address')))
		end 
	 END 


 
END

go

