CREATE VIEW dbo.View_commodity
AS
SELECT     TOP (100) PERCENT commodity, fullname, cname, density, order1, flash, nature
FROM         dbo.commodity
ORDER BY order1 DESC
go

