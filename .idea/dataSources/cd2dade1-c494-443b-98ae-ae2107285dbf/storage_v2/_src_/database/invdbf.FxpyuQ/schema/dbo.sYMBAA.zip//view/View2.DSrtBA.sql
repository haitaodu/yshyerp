CREATE VIEW dbo.View2
AS
SELECT     item_no, vessel, [desc], last_port, next_port, arr_date, arr_time, arr_draft, branch, start_date, start_time, fin_date, fin_time, f_line_d, f_line_t, moor_date, moor_time, 
                      nor_t_date, nor_t_time, nor_a_date, nor_a_time, s_sample_d, s_sample_t, f_sample_d, f_sample_t, sail_date, sail_time, unmoor_d, unmoor_t, a_clear_d, a_clear_t, 
                      flag
FROM         OPENQUERY(inv, 'select * from v_time where item_no="SVYGR-028-02466"') AS derivedtbl_1
go

