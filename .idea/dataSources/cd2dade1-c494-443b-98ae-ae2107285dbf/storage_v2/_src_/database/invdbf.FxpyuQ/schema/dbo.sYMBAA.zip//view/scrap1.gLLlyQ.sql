CREATE VIEW dbo.scrap1
AS
SELECT     scr_no, customer, date, new, color, tare, cover, quantity, charge, remarks
FROM         OPENQUERY(inv, 'select * from scrap') AS derivedtbl_1
go

