CREATE VIEW dbo.Vw_ship
AS
SELECT   dbo.shiplist.item_no, dbo.shiplist.ship_no, dbo.shiplist.date1, dbo.shiplist.date2, dbo.shiplist.barth, dbo.shiplist.ar_time, 
                dbo.shiplist.remarks, shiprec1.cargo AS commodity, shiprec1.customer, shiprec1.WW, shiprec1.BAL
FROM      dbo.shiplist INNER JOIN
                    (SELECT   item_no, cargo, customer, SUM(washwater) AS WW, AVG(balance) AS BAL
                     FROM      dbo.shiprec
                     WHERE   (ISNULL(d, ' ') = ' ')
                     GROUP BY item_no, customer, cargo) AS shiprec1 ON dbo.shiplist.item_no = shiprec1.item_no
WHERE   (ISNULL(dbo.shiplist.d, ' ') = ' ')
go

