CREATE VIEW dbo.View_customer
AS
SELECT     TOP (100) PERCENT customer, fullname, cname, order1
FROM         dbo.customer
ORDER BY order1 DESC
go

