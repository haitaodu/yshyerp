-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[readtank]

AS
BEGIN
  DECLARE @count int
    DECLARE @strSta  VARCHAR(2)
    SET @count = 1
declare @num int
 
 CREATE TABLE #t(tank char(7) default '',status char(1) default '0')
 
 select tank,t_use from tank where left(tank,1)='T'  order by tank
 END
go

