CREATE PROCEDURE  deletejob

@strTO VARCHAR(6)

AS

DECLARE

 @strUNIT_NAME VARCHAR(800)


 

SET @strUNIT_NAME=''


 

/*

處理update 的部分

*/

BEGIN TRANSACTION                                       

         IF @strTO<>''

        BEGIN
	 update  job_list set d='D' where job_no= 'T'+@strTO  and d=''
	 update ttdctemp set c_quan=0,c_station='',status=''  where jobno= @strTO  and d=''

        END


if   @@error=0   
COMMIT TRANSACTION
else   
rollback  TRANSACTION

RETURN 1
go

