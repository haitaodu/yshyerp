

CREATE PROCEDURE [dbo].[readsum]
(
@Time1 datetime,
@Time2 datetime
)
AS
 
   begin

 CREATE TABLE #finance(tank char(7),c_customer char(15),commodity char(15),crc_quan decimal(10,3) default 0,crc_num decimal(3,0) default 0,bulk_quan decimal(10,3) default 0,bulk_num decimal(3,0) default 0,ttdcin_quan decimal(10,3) default 0,ttdcin_num decimal(6,0) default 0,ttdc_quan decimal(10,3) default 0,ttdc_num decimal(6,0) default 0,fdm_quan decimal(9,3) default 0,fdm_num decimal(5,0) default 0,ddc_quan decimal(9,3) default 0,ddc_num decimal(5,0) default 0,fifo_quan decimal(9,3) default 0,fifo_num decimal(6,0) default 0)

insert into #finance (tank,c_customer,commodity,crc_quan,crc_num) select tank,c_customer,commodity,sum(actual) as crc_quan,count(tank) as crc_num from [invdbf].[dbo].[crc]  where isnull(D,'')<>'D' and date2>= @time1 and date2<=@time2 group by tank,c_customer,commodity 
insert into #finance (tank,c_customer,commodity,bulk_quan,bulk_num) select tank,c_customer,commodity,sum(actual) as bulk_quan,count(tank) as bulk_num from [invdbf].[dbo].[bulk]  where isnull(D,'')<>'D' and date2>=@time1 and date2<=@time2 group by tank,c_customer,commodity
insert into #finance (tank,c_customer,commodity,ttdc_quan,ttdc_num) select tank,c_customer,commodity,sum(netweight)/1000 as ttdc_quan,count(tank) as ttdc_num from [invdbf].[dbo].[ttdc]  where isnull(D,'')<>'D' and date2>=@time1 and date2<=@time2 and netweight>0  group by tank,c_customer,commodity
insert into #finance (tank,c_customer,commodity,ttdcin_quan,ttdcin_num) select tank,c_customer,commodity,sum(netweight)/1000 as ttdcin_quan,count(tank) as ttdcin_num from [invdbf].[dbo].[ttdc]  where isnull(D,'')<>'D' and date2>=@time1 and date2<=@time2 and netweight<0 group by tank,c_customer,commodity
insert into #finance (tank,c_customer,commodity,fdm_quan,fdm_num) select tank,c_customer,commodity,sum(drums*packing)/1000 as fdm_quan,sum(drums) as fdm_num from [invdbf].[dbo].[fdm] where isnull(D,'')<>'D' and date>=@time1 and date<=@time2 and slop='0'  group by tank,c_customer,commodity 
insert into #finance (tank,c_customer,commodity,ddc_quan,ddc_num) select tank,c_customer,commodity,sum(netweight)/1000 as ddc_quan,sum(drums) as ddc_num from [invdbf].[dbo].[ddc] where isnull(D,'')<>'D' and date2>=@time1 and date2<=@time2 and slop='0' group by tank,c_customer,commodity 
insert into #finance (tank,c_customer,commodity,fifo_quan,fifo_num) select tank,customer as c_customer ,commodity,sum(drums_out*packing)/1000 as fifo_quan,sum(drums_out) as fifo_num from [invdbf].[dbo].[drm_fifo]  where isnull(D,'')<>'D' and date2>=@time1 and date2<=@time2 group by tank,customer,commodity 


  select tank,c_customer,commodity,sum(crc_quan) as crc_quan,sum(crc_num) as crc_num,sum(bulk_quan) as bulk_quan,sum(bulk_num) as bulk_num,sum(ttdc_quan) as ttdc_quan,sum(ttdc_num) as ttdc_num,sum(ttdcin_quan) as ttdcin_quan,sum(ttdcin_num) as ttdcin_num,sum(fdm_quan) as fdm_quan,sum(fdm_num) as fdm_num,sum(ddc_quan) as ddc_quan,sum(ddc_num) as ddc_num,sum(fifo_quan) as fifo_quan,sum(fifo_num) as fifo_num from #finance  group by tank,c_customer,commodity 
  drop table #finance
  end

go

