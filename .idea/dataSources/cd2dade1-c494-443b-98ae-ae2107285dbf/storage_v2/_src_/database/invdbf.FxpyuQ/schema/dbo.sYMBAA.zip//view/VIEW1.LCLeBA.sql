CREATE VIEW dbo.VIEW1
AS
SELECT     date, customer, commodity, cover, state, color, tare, new, packing, batch, balance, quantity, remarks
FROM         OPENQUERY(inv, 'select * from exdrums') AS derivedtbl_1
go

