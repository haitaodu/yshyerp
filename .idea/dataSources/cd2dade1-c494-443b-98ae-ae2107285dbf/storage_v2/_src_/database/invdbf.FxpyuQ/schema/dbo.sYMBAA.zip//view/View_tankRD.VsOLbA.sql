CREATE VIEW dbo.View_tankRD
AS
SELECT     TOP (100) PERCENT date, tank, [level], le_time, le_qu, temp, te_time, te_qu, tov, to_time, to_qu, flow, fl_time, fl_qu
FROM         dbo.tank_rd
ORDER BY tank
go

