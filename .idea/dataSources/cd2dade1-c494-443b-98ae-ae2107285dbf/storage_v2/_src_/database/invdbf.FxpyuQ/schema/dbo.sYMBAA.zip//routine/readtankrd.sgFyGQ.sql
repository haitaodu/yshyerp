-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[readtankrd]
AS
   begin
SELECT a.tank,b.commodity,c.cname,a.[date],a.[level],a.temp,a.tov FROM  tank_rd AS a INNER JOIN tank AS b ON a.tank = b.tank and b.quantity>25000  and a.[level]<cast(b.tank_h as float) INNER JOIN  commodity AS c ON b.commodity = c.commodity
ORDER BY a.tank
  end
go

