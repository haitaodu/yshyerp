

CREATE PROCEDURE [dbo].[readjoblist]

@strGH VARCHAR(7)

AS
 
 begin
  
 CREATE TABLE #t(id int default 0,job_no char(8) default '',codeno char(5) default '',codeno1 char(5) default '',content char(50) default '',m_scan bit default 0,orderno char(2) default '00',scantime datetime default '',scanstatus char(10) default '',gh char(3) default '',permission char(4) default '',rfid char(32) default '')
 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid from job_list a,codelist b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.codeno ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid1 from job_list a,hpipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code1 ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid2 from job_list a,hpipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code2 ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid3 from job_list a,hpipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code3 ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid4 from job_list a,hpipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code4 ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid1 as rfid from job_list a,spipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code1 ') 
 exec('INSERT INTO #t  select a.id,job_no,a.codeno,a.codeno1,a.content,a.m_scan,a.orderno,scantime,scanstatus,gh,a.permission,rfid2 as rfid from job_list a,spipe b  where  job_no='''+@strGH+''' and  a.d='''' and a.codeno=b.code2 ') 

  select * from #t
  drop table #t
  end

go

