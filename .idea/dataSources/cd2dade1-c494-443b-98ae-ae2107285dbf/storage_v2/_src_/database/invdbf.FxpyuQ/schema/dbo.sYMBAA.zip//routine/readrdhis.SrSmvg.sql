
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[readrdhis]
@Time1 datetime
AS
   begin
SELECT     a.date, a.tank, a.[level], a.le_time, a.le_qu, a.temp, a.te_time, a.te_qu, a.tov, a.to_time, a.to_qu, a.flow, a.fl_time, a.fl_qu
FROM         [invDB].[dbo].[hist_rd] AS a INNER JOIN
                          (SELECT     tank, MAX(date) AS date
                            FROM          [invDB].[dbo].[hist_rd]
                            WHERE      (date BETWEEN dateadd(month,-1,@Time1) AND @Time1 )
                            GROUP BY tank) AS b ON a.tank = b.tank AND a.date = b.date
ORDER BY a.tank
  end

go

