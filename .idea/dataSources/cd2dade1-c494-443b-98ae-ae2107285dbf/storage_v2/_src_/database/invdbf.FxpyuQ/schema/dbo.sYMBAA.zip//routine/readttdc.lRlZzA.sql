CREATE PROCEDURE [dbo].[readttdc]
  
AS
 
   begin
   DECLARE @count int
    DECLARE @strSta  VARCHAR(2)
    SET @count = 1
declare @num int
 
 CREATE TABLE #t(station char(2) ,tank char(7) default '',tankcode char(2) default '',commodity char(15) default '',c_quan decimal(8,0) default 0,status char(2) default '00',level decimal(6,3) default 0,tov decimal(8,3) default 0,flow decimal(5,1) default 0,temp decimal(5,1) default 0,time decimal(8,0) default 0,flag char(1) default '0')
 
  WHILE @count <=10
    BEGIN
 	SET @strSta =right(str(@count +100),2)
	select @num=count(c_station)  from ttdctemp where d='' and c_station=@strSta and status<>'10' and status<>''
	if (@num=0)
	    BEGIN
		exec('INSERT INTO #t  (station,status) Values('''+@strSta+''',''00'')') 
            end	
	else
	    BEGIN
		exec('INSERT INTO #t  SELECT top 1 c_station,ttdctemp.tank,tank.code1,ttdctemp.commodity,c_quan*1000,status,tank_rd.level,tank_rd.tov,tank_rd.flow,tank_rd.temp,DATEDIFF(minute,tank_rd.date,GETDATE()),case  when DATEDIFF(minute,tank_rd.date,GETDATE()) > 30   then   ''0''   else  ''1''  end  FROM ttdctemp,tank,tank_rd  where ttdctemp.d='''' and ''T-''+SUBSTRING(ttdctemp.tank,3,4)=tank.tank and ''T-''+SUBSTRING(ttdctemp.tank,3,4)=tank_rd.tank and c_station='''+@strSta+''' and status between ''01'' and ''09'' order by status desc,c_time  ') 
            end	
	SET @count = @count +1
     end 	
  select * from #t
  drop table #t
  end
go

