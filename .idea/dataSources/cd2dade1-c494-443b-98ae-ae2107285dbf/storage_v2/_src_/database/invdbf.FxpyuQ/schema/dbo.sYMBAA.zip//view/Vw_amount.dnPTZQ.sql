CREATE VIEW dbo.Vw_amount
AS
SELECT   dbo.amount.id, dbo.amount.amountno, dbo.amount.date, dbo.amount.customer, dbo.amount.billid, dbo.amount.serviceid, 
                dbo.amount.amount, dbo.amount.remarks, dbo.Vw_contractservice.Name, dbo.Vw_contractservice.Unit, 
                dbo.Vw_contractservice.price, dbo.contract.contract_i, dbo.Vw_contractservice.taxrate, dbo.Vw_contractservice.istax, 
                dbo.contract.en_date, dbo.Receivables.State
FROM      dbo.amount INNER JOIN
                dbo.contract ON dbo.amount.billid = dbo.contract.id INNER JOIN
                dbo.Vw_contractservice ON dbo.amount.billid = dbo.Vw_contractservice.billid AND 
                dbo.amount.serviceid = dbo.Vw_contractservice.serviceid LEFT OUTER JOIN
                dbo.Receivables ON dbo.Receivables.no = 'AM' + dbo.amount.amountno
WHERE   (ISNULL(dbo.amount.d, ' ') = ' ') AND (ISNULL(dbo.Receivables.d, ' ') = ' ')
go

