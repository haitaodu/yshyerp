CREATE VIEW dbo.Vw_usequantity
AS
SELECT   TOP (100) PERCENT dbo.usequantity.id, dbo.usequantity.useno, dbo.usequantity.date, dbo.usequantity.customer, 
                dbo.usequantity.billid, dbo.usequantity.serviceid, dbo.usequantity.quantity, dbo.usequantity.remarks, 
                dbo.contract.en_date, dbo.Vw_contractservice.Name, dbo.Vw_contractservice.Unit, dbo.Vw_contractservice.price, 
                dbo.contract.contract_i, dbo.Vw_contractservice.taxrate, dbo.Receivables.State, dbo.Vw_contractservice.miniquan, 
                dbo.Vw_contractservice.freequan, dbo.Vw_contractservice.isnum
FROM      dbo.usequantity INNER JOIN
                dbo.contract ON dbo.usequantity.billid = dbo.contract.id INNER JOIN
                dbo.Vw_contractservice ON dbo.usequantity.billid = dbo.Vw_contractservice.billid AND 
                dbo.usequantity.serviceid = dbo.Vw_contractservice.serviceid LEFT OUTER JOIN
                dbo.Receivables ON dbo.Receivables.no = 'US' + dbo.usequantity.useno
WHERE   (ISNULL(dbo.usequantity.d, ' ') = ' ') AND (ISNULL(dbo.Receivables.d, ' ') = ' ')
go

