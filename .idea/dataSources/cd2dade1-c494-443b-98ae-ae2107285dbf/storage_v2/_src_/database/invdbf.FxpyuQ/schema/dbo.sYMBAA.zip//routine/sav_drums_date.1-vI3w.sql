


CREATE PROCEDURE  [dbo].[sav_drums_date]
@t_no VARCHAR(6)='0',
@output VARCHAR(100) output
AS
DECLARE
 @l_sql nVARCHAR(800),
 @t_no1 VARCHAR(6),
 @t_no2 VARCHAR(6),
 @status VARCHAR(6),
 @fdmdate datetime,
 @date2 datetime,
 @date_fee datetime,
 @c_date datetime,
 @code varchar(12),
 @tank varchar(7),
 @t_customer varchar(15),
 @c_customer varchar(15),
 @commodity varchar(15),
 @new varchar(3),
 @color varchar(12),
 @cover bit,
 @tare  Numeric(4,1),
 @type varchar(1),
 @drums int,
 @fdmdrums int,
 @balance int
 set @output=''




/*
處理update 的部分
*/
BEGIN TRANSACTION   
	if isnull(@t_no,'')='' 
		return 0 
    else
		begin
			select @code=code,@drums=drums,@status=status,@date2=date2 from ddc where jobno=@t_no and isnull(d,' ')=' '
			if @status='NORMAL'
			begin
				select @balance=balance,@date_fee=date_fee from drums where code1+code2=@code
				Declare Getfdm cursor static for
				SELECT  date,drums
				FROM   fdm
				WHERE   code1+code2 = @code and isnull(d,' ')=' '
				order by date desc 
				open  Getfdm
				--提取游标
				fetch First from Getfdm into @fdmdate,@fdmdrums
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
				begin
					begin 
						if @fdmdate>@date_fee or @date_fee>=@date2 ---灌桶后桶库存已月结，则以月结时间起算
							set @c_date =convert(datetime,CONVERT(varchar(10),@fdmdate, 120 ))
						else
							set @c_date = convert(datetime,CONVERT(varchar(10),@date_fee, 120 ))
						if @drums+@balance<@fdmdrums 
						begin
							set @output=@output+rtrim(ltrim(cast(@drums as varchar)))+'桶:'+rtrim(ltrim(cast(datediff(dd ,@c_date,@date2) as varchar)))+'天;'
							set @drums=0
							set @balance=0
						end
						else
						begin
							set @balance=@balance-@fdmdrums
							if @balance<0
							begin 
								set @output=@output+rtrim(ltrim(cast(@drums as varchar)))+'桶:'+rtrim(ltrim(cast(datediff(dd ,@c_date,@date2) as varchar)))+'天;'
								set @drums=@drums+@balance
								set @balance=0
							end
						end 
						if @balance=0 and @drums=0
							break
					end
					fetch next from  Getfdm into @fdmdate,@fdmdrums

				end
				close Getfdm --关闭游标 
				Deallocate Getfdm--释放游标
			end 	 
			if @status='SLOP'
			begin
				select  @tank=tank,@t_customer=t_customer,@c_customer=c_customer,@commodity=commodity,@new=new,@color=color,
						@cover=cover,@tare=tare,@type=type from ddc where jobno=@t_no and isnull(d,' ')=' '
				select @balance=balance from slop where tank=@tank and t_customer=@t_customer and c_customer=@c_customer 
						and commodity=@commodity and new=@new and color=@color and cover=@cover and tare=@tare and type=@type 
				Declare Getfdm cursor static for
				SELECT  date,drums
				FROM   fdm
				WHERE  tank=@tank and t_customer=@t_customer and c_customer=@c_customer and commodity=@commodity and new=@new 
						and color=@color and cover=@cover and tare=@tare and type=@type and isnull(d,' ')=' '
				order by date desc 
				open  Getfdm
				--提取游标
				fetch First from Getfdm into @fdmdate,@fdmdrums
				while @@fetch_status=0  --提取成功，进行下一条数据的提取操作 
				begin
					begin 
						if @drums+@balance<@fdmdrums
						begin
							set @output=@output+rtrim(ltrim(cast(@drums as varchar)))+'桶:'+rtrim(ltrim(cast(datediff(dd ,@fdmdate,@date2) as varchar)))+'天;'
							set @drums=0
							set @balance=0
						end
						else
						begin
							set @balance=@balance-@fdmdrums
							if @balance<0
							begin 
								set @output=@output+rtrim(ltrim(cast(@drums as varchar)))+'桶:'+rtrim(ltrim(cast(datediff(dd ,@fdmdate,@date2) as varchar)))+'天;'
								set @drums=@drums+@balance
								set @balance=0
							end
						end 
						if @balance=0 and @drums=0
							break
					end
					fetch next from  Getfdm into @fdmdate,@fdmdrums

				end
				close Getfdm --关闭游标 
				Deallocate Getfdm--释放游标
			end 
		end 

if   @@error=0   
	COMMIT TRANSACTION
else   
	rollback  TRANSACTION
--RETURN @output


go

