CREATE VIEW dbo.Vw_shipcrc
AS
SELECT   item_no, 'C' + crc_no AS no, c_customer, commodity, tank, date1, date2, actual, remarks
FROM      dbo.crc
union
SELECT   item_no, 'B' + bulk_no AS no, c_customer, commodity, tank, date1, date2, actual, remarks
FROM      dbo.[bulk]
WHERE   (ISNULL(d, ' ') = ' ')
go

