

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[readtankhis]
@Time1 datetime
AS
   begin
SELECT     a.tank, a.t_customer, a.commodity, a.balance, a.date
FROM         tank_bal AS a INNER JOIN
                          (SELECT     tank, MAX(id) AS id
                            FROM          tank_bal
                            WHERE      (date BETWEEN DATEADD(month, - 12, @Time1) AND @Time1) AND (LEFT(tank, 1) = 'T') AND (ISNULL(d, '') = '')
                            GROUP BY tank) AS b ON a.tank = b.tank AND a.id = b.id
ORDER BY a.tank
  end


go

