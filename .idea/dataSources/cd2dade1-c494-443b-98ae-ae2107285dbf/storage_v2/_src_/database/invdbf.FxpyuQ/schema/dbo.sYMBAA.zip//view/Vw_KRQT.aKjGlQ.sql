CREATE VIEW dbo.Vw_KRQT
AS
SELECT   dbo.DeviceData.DeviceID, dbo.DeviceData.equipType, dbo.DeviceData.equipName, dbo.DeviceData.equipBrand, 
                dbo.DeviceData.installDate, dbo.DeviceData.unitName, dbo.DeviceData.equipPosition, dbo.DeviceData.measuringLow, 
                dbo.DeviceData.measuringHigh, dbo.DeviceData.measureUnit, dbo.DeviceData.measurePrecision, 
                dbo.DeviceData.firstLimit, dbo.DeviceData.secondLimit, dbo.DeviceData.equipStatus, dbo.KRQT.[level] AS currentvalue, 
                dbo.KRQT.le_time AS updatetime
FROM      dbo.KRQT INNER JOIN
                dbo.DeviceData ON dbo.KRQT.KRQT = dbo.DeviceData.equipName
go

