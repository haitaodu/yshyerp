CREATE VIEW dbo.Vw_chargetype
AS
SELECT   c_name, e_name, d, code
FROM      dbo.other_dict
WHERE   (code = 'C1') AND (ISNULL(d, ' ') = ' ')
go

