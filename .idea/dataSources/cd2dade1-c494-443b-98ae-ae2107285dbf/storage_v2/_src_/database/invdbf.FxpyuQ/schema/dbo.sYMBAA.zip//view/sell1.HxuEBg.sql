CREATE VIEW dbo.sell1
AS
SELECT     sell_no, o_customer, customer, date, new, color, tare, cover, quantity, charge, remarks
FROM         OPENQUERY(inv, 'select * from sell where sell_no>''002128'' ') AS derivedtbl_1
go

