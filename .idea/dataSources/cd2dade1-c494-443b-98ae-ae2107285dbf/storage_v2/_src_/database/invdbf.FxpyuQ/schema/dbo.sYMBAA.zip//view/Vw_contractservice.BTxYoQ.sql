CREATE VIEW dbo.Vw_contractservice
AS
SELECT   dbo.contract.contract_i, dbo.contractlist.billid, dbo.contractlist.serviceid, dbo.Service.Name, dbo.Service.Unit, 
                dbo.Service.ChargeType, dbo.contractlist.price, dbo.contract.customer, dbo.contractlist.taxrate, dbo.contractlist.istax, 
                dbo.contractlist.miniquan, dbo.contractlist.freequan, dbo.contractlist.isnum
FROM      dbo.Service INNER JOIN
                dbo.contractlist ON dbo.Service.ServiceID = dbo.contractlist.serviceid INNER JOIN
                dbo.contract ON dbo.contractlist.billid = dbo.contract.id
WHERE   (ISNULL(dbo.contract.d, ' ') = ' ') AND (ISNULL(dbo.contractlist.D, ' ') = ' ')
go

